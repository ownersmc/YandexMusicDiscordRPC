# Publishing

## Что выкладывать в репозиторий

Коммитьте исходники и служебные файлы:

- `yd_discord_presence.py`
- `requirements.txt`
- `README.md`
- `README_START.txt`
- `config.example.json`
- `run.bat`
- `run.ps1`
- `build_release.bat`
- `build_release.ps1`
- `.github/workflows/build-windows.yml`
- `.gitignore`

Не коммитьте локальные и сгенерированные файлы:

- `.venv/`
- `config.json`
- `cache/`
- `build/`
- `dist/`
- `release/`
- `WinYandexMusicRPC-main/`

Они уже добавлены в `.gitignore`.

## Как сделать готовый архив для пользователей

Локально:

```bat
build_release.bat
```

После сборки появится:

```text
YandexMusicDiscordRPC-portable.zip
```

Его нужно загрузить в GitHub Releases. Пользователь скачивает zip, распаковывает и запускает `YandexMusicDiscordRPC.exe`.

## GitHub Actions

Workflow `.github/workflows/build-windows.yml` собирает portable exe:

- вручную через `Actions -> Build Windows exe -> Run workflow`;
- автоматически при push тега вида `v1.0.0`.

После запуска workflow скачайте artifact `YandexMusicDiscordRPC-portable` и прикрепите zip к GitHub Release.
